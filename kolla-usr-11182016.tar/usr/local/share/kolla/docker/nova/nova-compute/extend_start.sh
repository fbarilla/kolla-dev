#!/bin/bash

# /bin/bash
# exit 0


# Bootstrap and exit if KOLLA_BOOTSTRAP variable is set. This catches all cases
# of the KOLLA_BOOTSTRAP variable being set, including empty.
if [[ "${!KOLLA_BOOTSTRAP[@]}" ]]; then
    mkdir -p /var/lib/nova/instances
    exit 0
fi
